#/bin/bash
#======================================================
# Projet : PLGS
# Produit par Capgemini
#======================================================
# HISTORIQUE
# VERSION:1.1.0::::Creation
# VERSION:1.1.0:Story:MCA_PLGS_T-331:11/03/2021:Mise au point des lancement des tests cucumber après un déploiement complet du PLGS
# FIN-HISTORIQUE
#======================================================

function name(){
	    echo "prog-val"
    }

function dependencies(){
	    echo ""
    }

function build(){

    # Build of dpu ansible
    # type ansible
    echo "Nothing to build"

}

function extract(){
    # Export tec-mpp-pfw
    echo "Nothing to extract"

}
