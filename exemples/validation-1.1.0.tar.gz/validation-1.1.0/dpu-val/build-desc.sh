#/bin/bash
#======================================================
# Projet : PLGS
# Produit par Capgemini
#======================================================
# HISTORIQUE
# VERSION:1.1.0::::Creation
# VERSION:1.1.0:Story:MCA_DPU_T-471:11/03/2021:Capgemini validation platform deployment
# FIN-HISTORIQUE
#======================================================

function name(){
	    echo "dpu-val"
    }

function dependencies(){
	    echo ""
    }

function build(){

    # Build of dpu ansible
    # type ansible
    build_docker "build/inbox/Dockerfile" "dpu/dpu-val-inbox"
    build_docker "build/pf/Dockerfile" "dpu/dpu-val-pm"
    build_docker "build/archiver/Dockerfile" "dpu/dpu-val-archiver"

}

function extract(){
    # Export tec-mpp-pfw
    extract_docker "dpu/dpu-val-inbox" "dpu/dpu-val" "dpu-val-inbox.tar.gz"
    extract_docker "dpu/dpu-val-pm" "dpu/dpu-val" "dpu-val-pm.tar.gz"
}
