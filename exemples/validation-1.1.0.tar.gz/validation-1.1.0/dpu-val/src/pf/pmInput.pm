#
# $Id$
# Interface to the Input processing of the PM.
# This module may be called either from a CGI script, or from elsewhere
# provided that the correct parameters are provided.
#
package pmInput;
require 5.004;

use FileHandle;
use Digest::MD5 qw(md5_base64);
use Time::gmtime;

use pmParserV3;
use pmUtils;
use pmWorklist;
use pmRulefile;
use pmCentre;
use pmEvents;

use strict;

sub new
{
    my $class = shift;
    my $self = {};
    bless ($self, $class);
    return ($self);
} # new

### Code to be executed at module load time ###
### NB: Also executed by perl -c            ###
my $utils = new pmUtils;
my $work  = new pmWorklist;
my $rule  = new pmRulefile;
my $cent  = new pmCentre;
my $parser = new pmParserV3;
my $evt   = new pmEvents;

my $centre = $cent->processing_centre();

if (!defined ($centre))
{
    $utils->err_log ("No processing_centre defined");
    $centre = "UNKN";
}
### End of code to be excecuted at module load time ###

#
# pm_Input:
# Get all params and optional params from PM Input notification, then process.
#
sub pm_Input
{
    my ($self, $command_id, $input_type, $input_path, $incomplete,
	$err_info, $thelast, $pstart, $pstop, $thecount, $timefirst,
	$timeouts,
	$use_rules, $themission, $thesat, $url) = (@_);

    #
    # The production rules file to use:
    #
    my $production_rules;
    my $start_exe;
    my $stop_exe;
    my $start_sensing;
    my $stop_sensing;
    my $sat_id;
    my $tmp_sat;
    my $mand_aux_conf;
    my $mission;

    my $file = $utils->my_basename ($input_path);

    $mission = $themission if $themission;
    $sat_id  = $thesat if $thesat;
    
    if (!$themission) # Timeouts etc. need to set themission in advance.
    {
	# For others, figure out from filename where possible:
	if ($file =~ /^S6._/) # Jason CS product or aux file
	{
	    $mission = "Jason";
	}
        elsif ($file =~ /^MC._/) # As Jason CS product or aux file naming convention rules
        {
            $mission = "Jason";
        }
	elsif ($file =~ /^.{11}_([NM]\d{2})_/)
	{
	    $mission = "EPS"; # EPS product or aux file 
	}
	else
	{
	    $mission = "Default"; # Everything else (including ISP files)
	}
    }

    $mission = "Default" unless defined ($mission);

    if ($mission eq "EPS")
    {
	($production_rules, $start_exe, $stop_exe,
	 $start_sensing, $stop_sensing,
	 $tmp_sat, $mand_aux_conf) = $rule->dump_info($command_id);
	$sat_id = $tmp_sat unless defined ($sat_id);
	$parser->set_generic (0);
    }
    elsif ($mission eq "Jason")
    {
	$sat_id = unpack ("A3", $file) unless defined ($sat_id);
	$parser->set_generic (0);	    
    }
    else
    {
	# Everything else (including ISP files):
	$parser->set_generic (1);

    }
    
    if (defined ($use_rules) && $use_rules)
    {
	# Override production rules from rules_file:
	my $prules_file = $rule->abs_prules ($use_rules);
	$production_rules = $prules_file if defined ($prules_file);
    }

    log_input ($command_id, $input_type, $input_path, $incomplete,
	       $err_info, $thelast, $pstart, $pstop, $thecount, $timefirst,
	       $timeouts,
	       $production_rules, $themission, $thesat);

    my $prulesfile = new FileHandle ($production_rules, O_RDONLY);
    if (!defined ($prulesfile))
    {
	die ("Could not open $production_rules: $!");
    }
    
    my $prules_hash = md5_base64 ($production_rules);
    $prules_hash = "" unless defined ($prules_hash);

    $_ = <$prulesfile>;
    if (/\(\@\)\s+PRULES_FORMAT\s+(\d+\w*)/)
    {
	my $version = $1;
	my ($maj, $min) = split /_/, $version;
	if ($maj < 3)
	{
	    $utils->err_log ("Parser V2 not supported $production_rules");
	    return (1);
	}
    }
    else
    {
	my $err = "(@) PRULES_FORMAT <format> missing";
	$utils->err_log ("$production_rules: Incorrect first line: $err");
	return (1);
    }
    close ($prulesfile);

    if (defined($start_exe))
    {
	$start_exe = $utils->etime2seconds ($start_exe);
	$parser->set_start_exe ($start_exe);
    }
    
    if (defined($stop_exe))
    {
	$stop_exe = $utils->etime2seconds ($stop_exe);
    }

    if (defined($start_sensing))
    {
	$start_sensing = $utils->etime2seconds ($start_sensing);
	$parser->set_start_sensing ($start_sensing);
    }

    if (defined($stop_sensing))
    {
	$stop_sensing = $utils->etime2seconds ($stop_sensing);
	$parser->set_stop_sensing ($stop_sensing);
    }

    if (defined($mission))
    {
	$parser->set_mission ($mission);
    }

    if (defined($prules_hash))
    {
	$parser->set_prules_hash ($prules_hash);
    }

    $parser->set_command_id ($command_id);
    $parser->set_production_rules ($production_rules);
    $parser->set_current_url ($url);
    $parser->set_processing_centre ($centre);
    if (defined ($use_rules) && $use_rules)
    {
	$parser->set_rules_to_pass ($use_rules);
    }

    if (defined ($sat_id))
    {
	$parser->set_sat_id ($sat_id);
    }
    
    if (defined ($mand_aux_conf))
    {
	$parser->set_mand_aux_conf ($mand_aux_conf);
    }

    # We need this temporarily, until the upgraded production rules format
    # has been completed.
    my $auto_handler;
    my ($type, $subtype, $level, $satellite);

    # Flag if an input should be ignored (partly or fully):
    my $ignore = 0;
    
    if (($mission eq "EPS" && (length ($input_type) >= 15)))
    {
	($type, $subtype, $level, $satellite) =
	    unpack ("A4 x1 A3 x1 A2 x1 A3", $input_type);

	if ($satellite =~ /^[NM]\d{2}/)
	{
	    if ($level eq "00")
	    {
		if ($type =~ /^[a-z]/)
		{
		    $auto_handler = "SLICE";
		}
		elsif ($type =~ /^[A-Z]/)
		{
		    $auto_handler = "PDU";
		}
	    }
	    elsif (substr ($level, 0, 1) eq "1")
	    {
		$auto_handler = $level;
	    }
	}
    }
    # aux input notifications have command ID 0. Always let them through.
    elsif ($command_id && $mission eq "Jason")
    {
	# Generic track-keeping of input:
	my $global = "global";
	my $null   = 0; # Dummy (global) 'rule no'
	my ($zstart, $zstop) = $parser->get_start_stop ("n/a", $command_id,
							$file, $pstart,
							$pstop, 0);
	my $estart = $utils->ztime2seconds ($zstart);
	my $estop  = $utils->ztime2seconds ($zstop);
	my $res = $parser->is_processed ($command_id, $prules_hash, $sat_id,
					 $global, $null,
					 $input_type, $estart, $estop);
	if (!defined($timeouts) && $res)
	{
	    $ignore = 2; # Jason: Ignore completely (dup)
	    my $msg = "Duplicate $file";
	    $evt->log_warning ($msg, $command_id, $sat_id);
	}
	else
	{
	    $parser->add_file ($mission, $command_id, $prules_hash, $sat_id,
			       $global, $null,
			       $input_type, $file, $input_path,
			       $estart, $estop);

	    $parser->set_processed ($command_id, $prules_hash, $sat_id,
				    $global, $null,
				    $input_type, $estart, $estop);
	}
    }

    if (defined ($auto_handler)) # EPS only
    {
	my $kind = $auto_handler;

	if (!$incomplete)
	{
	    my $new_file = $file;
	    # Strip terminating .<number> if any:
	    $new_file =~ s/\.\d+$//;
	    # Make symlink right away so that we don't get a race condition
	    # where the file is present in the planning entry but not in
	    # the URL/link directory.  Affects ATOVS mostly.
	    $utils->mksymlink ($input_path, $new_file, $command_id);
	}
	    
	$ignore = $parser->update_plan_entry ($kind, $command_id, $file,
					      $incomplete, $err_info,
					      $pstart, $pstop, $thecount,
					      $thelast);
	# Not sending timeouts to update_plan_entry
    }

    # Now call parser.
    $parser->process_input ($command_id, $input_type, $input_path, $ignore,
			    $incomplete, $err_info, $thelast, $pstart, $pstop,
			    $thecount, $timefirst, $timeouts, $auto_handler);
    return (0);
} # pm_Input
							
#
# Add one line to the global PM input logfile.
#
sub log_input
{
    my ($command_id, $input_type, $input_path, $incomplete,
	$err_info, $thelast, $pstart, $pstop, $thecount, $timefirst, $timeouts,
	$production_rules, $themission, $thesat) = (@_);
    
    my $logfile = $work->log_path;
    my $rulesfile = $utils->my_basename ($production_rules);
    my $fh = new FileHandle ($logfile, O_CREAT | O_WRONLY | O_APPEND, 0666);
    if (!defined ($fh))
    {
	print (STDERR "Could not open $logfile $!\n");
	print ("Could not open $logfile\n");
	exit (1);
    }
    else
    {
	if (!flock ($fh, 2))
	{
	    print ("Warning, could not lock $logfile $!\n");
	}
	my $tm = gmtime;
	my $stamp = sprintf ("%04d-%02d-%02d %02d:%02d:%02d",
			     $tm->year+1900, $tm->mon+1, $tm->mday,
			     $tm->hour, $tm->min, $tm->sec);
	printf $fh "%s:cmd_id=\"%s\",type=\"%s\",path=\"%s\" rules=%s",
	  $stamp, $command_id, $input_type, $input_path,
  	  $rulesfile;
	
	print $fh " pstart=$pstart" if defined ($pstart);
	print $fh " pstop=$pstop" if defined ($pstop);
	print $fh " incomplete" if defined ($incomplete);
	print $fh " $err_info" if defined ($err_info);
	print $fh " count=$thecount" if defined ($thecount);
	print $fh " timefirst=$timefirst" if defined ($timefirst);
	print $fh " timeouts=$timeouts" if defined ($timeouts);
	print $fh " last" if defined ($thelast);
	print $fh " mission=$themission" if defined ($themission);
	print $fh " satellite=$thesat" if defined ($thesat);
	print $fh "\n";

	close ($fh);
    }
} # log_input

1;
