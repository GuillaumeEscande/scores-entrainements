#!/bin/bash
# ======================================================
# Projet : PLGS
# Produit par Capgemini
# ======================================================
# HISTORIQUE
# VERSION:1.1.0::::Creation
# VERSION:1.1.0:Story:MCA_DPU_T-471:11/03/2021:Capgemini validation platform deployment
# FIN-HISTORIQUE
# ======================================================


# Run the HTTP daemon
httpd -DFOREGROUND
