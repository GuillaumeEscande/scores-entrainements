#/bin/bash
#======================================================
# Projet : PLGS
# Produit par Capgemini
#======================================================
# HISTORIQUE
# VERSION:0.2.0::::Creation
# VERSION:1.1.0:Story:MCA_DPU_T-471:11/03/2021:Capgemini validation platform deployment
# VERSION:1.1.0:Story:MCA_PLGS_T-331:11/03/2021:Mise au point des lancement des tests cucumber après un déploiement complet du PLGS
# FIN-HISTORIQUE
#======================================================

function name(){
	    echo "validation"
    }

function dependencies(){
	    echo "pltmframe-generator local-archive-simulator pilote-val dpu-val prog-val"
    }

function build(){

         build_ansible "ansible-validation"
}

function extract(){
    # Export local-archive-simulator
    info "Extract : Empty String"
}
