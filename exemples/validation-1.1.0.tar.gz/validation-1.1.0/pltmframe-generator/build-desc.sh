#/bin/bash
#======================================================
# Projet : PLGS
# Produit par Capgemini
#======================================================
# HISTORIQUE
# VERSION:0.2.0::::Creation
# FIN-HISTORIQUE
#======================================================

function name(){
	    echo "pltmframe-generator"
    }

function dependencies(){
	    echo ""
    }

function build(){
    build_docker "build/Dockerfile" "validation/pltmframe-generator"
}

function extract(){
    info "TODO"
}

