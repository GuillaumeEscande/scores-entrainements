#!/usr/bin/env python3.7.4
# -*- coding: utf-8 -*-

"""
# * ======================================================
# *
# * Projet : PLGS
# * Produit par Capgemini
# *
# * ======================================================
# * HISTORIQUE
# * VERSION:0.2.0::::Creation  
# * FIN-HISTORIQUE
# * ======================================================
"""
import os
import subprocess
from zip_generator import parser_config, first_generator, generator, end_move

def test_parser_config():
    """
    Fonction pour tester parser_config() de ZipGenerator.py
    """

    cmd_line = ['-n', '4', '-s', '300', '-d', '500', '-p', './X-BAND-ET',
        '--ftp', 'on', '--addr', 'localhost', '--user', 'eladeira', '--pwd', '1234']
    args = parser_config(cmd_line)
    args_details = [args.number, args.size, args.delay, args.path,
        args.ftp, args.addr, args.user, args.pwd]
    assert ['4', '300', '500', './X-BAND-ET', 'on', 'localhost', 'eladeira', '1234'] == args_details

def test_fisrt_generator():
    """
    Fonction pour tester fisrt_generator() de ZipGenerator.py
    """

    os.system('rm ./X-BAND-ET/*')
    file_created_name = first_generator(30, './X-BAND-ET')

    #On récuèpre le contenu du dossier cible
    proc = subprocess.Popen('ls ./X-BAND-ET',
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,)

    stdout = proc.communicate()[0]
    stdout_str = "".join([chr(_) for _ in stdout])
    stdout_list = stdout_str.split()

    #On recupère la taille de l'archive créée
    proc2 = subprocess.Popen(
        'stat ./X-BAND-ET/{file} -c %s'.format(file=file_created_name), 
        shell=True, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.PIPE)

    stdout2 = proc2.communicate()[0]
    stdout2_int = int(stdout2)

    assert stdout_list[0] == file_created_name
    assert stdout2_int/2**20 - 30 <= 1

def test_fisrt_generator2():
    """
    Fonction pour tester fisrt_generator() de ZipGenerator.py
    """

    os.system('rm ./X-BAND-ET/*')
    file_created_name = first_generator(300, './X-BAND-ET')

    #On récuèpre le contenu du dossier cible
    process = subprocess.Popen('ls ./X-BAND-ET',
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,)

    stdout = process.communicate()[0]
    stdout_str = "".join([chr(_) for _ in stdout])
    stdout_list = stdout_str.split()

    #On recupère la taille de l'archive créée
    process2 = subprocess.Popen(
        'stat ./X-BAND-ET/{file} -c %s'.format(file=file_created_name), 
        shell=True, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.PIPE)

    stdout2 = process2.communicate()[0]
    stdout2_int = int(stdout2)

    assert stdout_list[0] == file_created_name
    assert stdout2_int/2**20 - 300 <= 1

def test_generator():
    """
    Fonction pour tester generator() de ZipGenerator.py
    """

    os.system('rm ./X-BAND-ET/*')
    file_created_name = first_generator(300, './X-BAND-ET')
    file_created_list = generator(4, 500, file_created_name, './X-BAND-ET')

    #On récuèpre le nombre d'archive venant d'être créées
    proc = subprocess.Popen(
        'find ./X-BAND-ET -type f -name \'*.temp\' | wc -l',
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,)

    stdout = proc.communicate()[0]
    stdout_int = int(stdout)

    #On récupère la liste des archives venant d'être créées
    proc2 = subprocess.Popen(
        'ls ./X-BAND-ET/*.temp', 
        shell=True, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.PIPE)

    stdout2 = proc2.communicate()[0]
    stdout2_str = "".join([chr(_) for _ in stdout2])
    stdout2_list = stdout2_str.splitlines()
    stdout2_list_name = [string[12:] for string in stdout2_list]

    #On recupère la taille des archives venant d'être créées
    proc3 = subprocess.Popen(
        'stat ./X-BAND-ET/*.temp -c %s', 
        shell=True, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.PIPE)

    stdout3 = proc3.communicate()[0]
    stdout3_str = "".join([chr(_) for _ in stdout3])
    stdout3_list = stdout3_str.split()
    stdout3_list_int = [int(string) for string in stdout3_list]

    assert stdout_int == 4
    assert stdout2_list_name == file_created_list

    for integer in stdout3_list_int:
        assert integer/2**20 - 300 <= 1

def test_end_move():
    """
    Fonction pour tester end_move() de ZipGenerator.py
    """

    os.system('rm ./X-BAND-ET/*')
    file_created_name = first_generator(300, './X-BAND-ET')
    file_created_list = generator(4, 500, file_created_name, './X-BAND-ET')
    end_move(file_created_list, './X-BAND-ET')

    #On récupère le nombre d'archives qui ont bien été renommées
    proc = subprocess.Popen(
        'find ./X-BAND-ET -type f -name \'*.gz\' | wc -l',
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,)

    stdout = proc.communicate()[0]
    stdout_int = int(stdout)

    assert stdout_int == 4












