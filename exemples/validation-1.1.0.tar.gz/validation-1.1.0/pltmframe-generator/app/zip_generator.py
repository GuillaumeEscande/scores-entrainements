#!/usr/bin/env python3.7.4
# -*- coding: utf-8 -*-

"""
# * ======================================================
# *
# * Projet : PLGS
# * Produit par Capgemini
# *
# * ======================================================
# * HISTORIQUE
# * VERSION:0.2.0::::Creation  
# * FIN-HISTORIQUE
# * ======================================================
"""

import argparse
import os
import sys
import gzip
from time import strftime, sleep
import shutil
from ftplib import FTP

def parser_config(args_cmd=None):
    """
    Définition et récupération des arguments de la ligne de commande
    """

    parser = argparse.ArgumentParser(prog='ZipGenerator')
    parser.add_argument("-n", "--number", type=str,
                    help="number of files to be created")
    parser.add_argument("-s", "--size", type=str,
                    help="size (Mo, must be a multiple of 10) of files to be created")
    parser.add_argument("-d", "--delay", type=str,
                    help="time (ms) between the end of a creation and a new one")
    parser.add_argument("-p", "--path", type=str,
                    help="folder absolute path where files are created")
    parser.add_argument("--ftp", type=str, nargs='?',
                    help="use of FTP tranfsert")
    parser.add_argument("--addr", type=str, nargs='?',
                    help="address for FTP connexion")
    parser.add_argument("--user", type=str, nargs='?',
                    help="user for FTP connexion")
    parser.add_argument("--pwd", type=str, nargs='?',
                    help="password for FTP connexion")
    result = parser.parse_args(args_cmd)
    
    return result

def first_generator(file_size, path):
    """
    Création d'un fichier texte (10Mo ou 100Mo).
    Génération d'une première archive de la taille souhaitée à partir du fichier texte 
    """

    #Génération du ficier texte. 
    #Estimation nombre de copies nécessaire pour avoir la taille d'archive souhaitée
    if file_size < 100:
        cmd = 'dd if=/dev/zero of={p}/file10Mo.txt bs=1024 count=0 seek=$[1024*10]'.format(p=path)
        os.system(cmd)
        txt_generated_name = 'file10Mo.txt'
        txt_file_number = file_size//10

    else:
        cmd = 'dd if=/dev/zero of={p}/file100Mo.txt bs=1024 count=0 seek=$[1024*100]'.format(p=path)
        os.system(cmd)
        txt_generated_name = 'file100Mo.txt'
        txt_file_number = file_size//100
    
    #Création de la prmière archive
    first_file_name = 'CARB_AUX_PLTM_F_' + strftime("%Y%m%dT%H%M%S") + '.gz.temp'
    compteur = 0
    #Copie du fichier de référence dans l'archive jusqu'à obtenir la taille souhaitée
    while compteur < txt_file_number:
        with open(path + '/{file}'.format(file=txt_generated_name), 'rb') as f_in:
            with gzip.open(path + '/{file}'.format(file=first_file_name), 'ab', 0) as f_out:
                shutil.copyfileobj(f_in, f_out)
        compteur += 1

    return first_file_name

        
def generator(number, delay, file_name, path):
    """
    Copie de la 1ère archive générée autant (number-1) fois pour avoir le nombre d'archives souhaité
    Nom des archives au format 'CARB_ETID_PLTM_F_YYYYMMDDTHHMMSS.gz.temp'
    """

    file_created_list = [file_name]
    compteur = 0
    #Copie du nombre de fichiers à générer restant
    while compteur < number -1:
        tmp_name = 'CARB_AUX_PLTM_F_' + strftime("%Y%m%dT%H%M%S") + '.gz.temp'
        file_created_list.append(tmp_name)
        #Copie avec renommage
        shutil.copy(path + '/{file}'.format(file=file_name), path + '/{file}'.format(file=tmp_name))
        compteur += 1
        #Temps avant de passer à la génération de l'archive suivante
        sleep(delay/1000)

    return file_created_list

def end_move(file_list, path):
    """
    Renommage de toutes les archives.
    On enlève le .temp pour avoir le nom au format 'CARB_ETID_PLTM_F_YYYYMMDDTHHMMSS.gz'
    """

    for name in file_list:
        shutil.move(path + '/{file}'.format(file=name), path + '/{file}'.format(file=name[:-5]))


if __name__ == '__main__':

    args = parser_config(sys.argv[1:])

    #Génération locale des fichiers
    if args.ftp is None:
        first_file = first_generator(int(args.size), args.path)
        sleep(int(args.delay)/1000)
        file_generated_list = generator(int(args.number), int(args.delay), first_file, args.path)
        end_move(file_generated_list, args.path)
    
    #Génération de fichiers sur une machine distante via un tranfert FTP
    else:
        #Création d'un premier fichier localement
        filename = first_generator(int(args.size), ".")
        sleep(int(args.delay)/1000)

        #Mise en place de la connexion FTP
        ftp = FTP(args.addr, args.user, args.pwd)
        #Changement de répertoire de travail sur la machine distante
        ftp.cwd(args.path)
        for i in range(int(args.number)):
            #Envoie du nombre de fichiers souhaité
            if i == 0:
                #Envoie binaire du fichier via FTP
                ftp.storbinary('STOR '+filename, open(filename, 'rb'))
                #Renommage au format 'CARB_ETID_PLTM_F_YYYYMMDDTHHMMSS.gz'
                ftp.rename(filename, filename[:-5])
                sleep(int(args.delay)/1000)

            else:
                #Mise à jour du nom de fichier
                filename, tmp = 'CARB_AUX_PLTM_F_' + strftime("%Y%m%dT%H%M%S") + '.gz.temp', filename
                os.rename(tmp, filename)
                #Envoie binaire du fichier via FTP
                ftp.storbinary('STOR '+filename, open(filename, 'rb'))
                #Renommage au format 'CARB_ETID_PLTM_F_YYYYMMDDTHHMMSS.gz'
                ftp.rename(filename, filename[:-5])
                sleep(int(args.delay)/1000)

        ftp.quit()
        #Suppression du fichier créé localement
        os.remove(filename)
