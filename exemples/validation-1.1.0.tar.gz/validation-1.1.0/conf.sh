#/bin/bash
#======================================================
# Projet : PLGS
# Produit par Capgemini
#======================================================
# HISTORIQUE
# VERSION:0.2.0::::Creation
# FIN-HISTORIQUE
#======================================================


##############################################
## Configuration de versions
##############################################

export VERSION=${VERSION:-"1.1.0"}
export GROUND_BASE_VERSION=${GROUND_BASE_VERSION:-"1.1.0"}
export PLGS_VERSION=${PLGS_VERSION:-"1.1.0"}

