
 # ======================================================
 # Projet : PLGS
 # Produit par Capgemini
 # ======================================================
 # HISTORIQUE
 # VERSION:0.2.0::::Creation
 # VERSION:1.0.0::::Creation du cartouche
 # VERSION:1.1.0:Story:MCA_PLGS_T-226:11/03/2021:Analyse préliminaire de l'automatisation de l'analyse qualité d'un composant/bundle
# VERSION:1.1.0:Story:MCA_PLGS_T-329:11/03/2021:Activer TU dans le build sans bloquer le build
# FIN-HISTORIQUE
 # ======================================================
 
 #!/bin/bash

SCRIPT="$(readlink -f "$0")"
COMPONENT_PATH="$(dirname "$SCRIPT")"

# Effectue physiquement la montée de version de chaque fichier
# Arguments : <nouvelle_version>

NEWVER=$1
GBVER=$2


# Gère la modification de chaque fichier individuellement
sed -i "s#^VERSION=.*#VERSION=${NEWVER}#g" "${COMPONENT_PATH}/doc/design.adoc"

sed -i "s#\(VERSION:-\"\).*\(\".*\)#\1${NEWVER}\2#g" "${COMPONENT_PATH}/conf.sh"
sed -i "s#\(GROUND_BASE_VERSION:-\"\).*\(\".*\)#\1${GBVER}\2#g" "${COMPONENT_PATH}/conf.sh"
sed -i "s#\(PLGS_VERSION:-\"\).*\(\".*\)#\1${PLGS_VERSION}\2#g" "${COMPONENT_PATH}/conf.sh"


xmlstarlet ed --inplace -P -N xsi="http://maven.apache.org/POM/4.0.0" -u "/xsi:project/xsi:version" -v "${NEWVER}"                                                                      "${COMPONENT_PATH}/local-archive-simulator/app/pom.xml"
xmlstarlet ed --inplace -P -N xsi="http://maven.apache.org/POM/4.0.0" -u "/xsi:project/xsi:parent/xsi:version" -v "${GBVER}"                                                            "${COMPONENT_PATH}/local-archive-simulator/app/pom.xml"

#test-report-processor
sed -i "s#VERSION = \".*\"#VERSION = \"${NEWVER}\"#g" "${COMPONENT_PATH}/test-report-processor/app/setup.py"
