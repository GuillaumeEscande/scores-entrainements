#/bin/bash
#======================================================
# Projet : PLGS
# Produit par Capgemini
#======================================================
# HISTORIQUE
# VERSION:0.2.0::::Creation
# FIN-HISTORIQUE
#======================================================

function name(){
	    echo "local-archive-simulator"
    }

function dependencies(){
	    echo ""
    }

function build(){

    # Build of local-archive-simulator
    # type java
    build_java

    VERSION_MVN="$(get_maven_version)"

    # Copie jar files needed by docker images
    copy_generated_jar "local-archive-simulator-${VERSION_MVN}.jar" "build/local-archive-simulator.jar"

    # Build of local-archive-simulator docker images
    # type docker

    build_docker "build/Dockerfile" "validation/local-archive-simulator"
}

function extract(){
    # Export local-archive-simulator
    info "Extract : Empty String"
}
