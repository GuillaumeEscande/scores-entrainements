#!/bin/bash
# ======================================================
# Projet : PLGS
# Produit par Capgemini
# ======================================================
# HISTORIQUE
# VERSION:0.2.0::::Creation
# FIN-HISTORIQUE
# ======================================================
export JAR=local-archive-simulator.jar
export CLASS=fr.cnes.microcarb.validation.localarchive.LocalArchiveImporter
export CONFIG=config.properties
java -cp ${JAR} ${CLASS} ${CONFIG}
