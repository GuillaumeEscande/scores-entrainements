/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Timer;
import java.util.TimerTask;

import fr.cnes.microcarb.validation.localarchive.monitoring.ElasticMonitoringAgent;
import fr.cnes.microcarb.validation.localarchive.monitoring.MonitoringAgent;
import fr.cnes.microcarb.validation.localarchive.monitoring.MonitoringException;

/**
 * Local archive importer daemon.
 * @author Capgemini
 * @since 0.1.2
 */
public class LocalArchiveImporterTask extends TimerTask {

    /**
     * Display the daemon help and exit.
     */
    private static void displayHelpAndExit() {
        System.err.println("Five arguments expected");
        System.out.println("1. Name of the data type");
        System.out.println("2. Input directory");
        System.out.println("3. Output directory");
        System.out.println("4. Polling period in seconds");
        System.out.println("5. URL of the monitoring server");
        System.out.println("6. (optional) ElasticSearch user login");
        System.out.println("7. (optional) ElasticSearch user password");
        System.exit(-1);
    }

    /**
     * Display a message and exit.
     * @param message
     *            Message to display
     */
    private static void displayMessageAndExit(String message) {
        System.err.println(message);
        System.exit(-1);
    }

    /**
     * Main function.
     * @param args
     *            Arguments of the daemon
     *            <ol>
     *            <li>Name of the data type</li>
     *            <li>Input directory</li>
     *            <li>Output directory</li>
     *            <li>Polling period in seconds</li>
     *            <li>PLGS-LOG address</li>
     *            <li>ElasticSearch user login</li>
     *            <li>ElasticSearch user password</li>
     *            </ol>
     */
    public static void main(String[] args) {
        // Read the arguments
        if (args.length != 5 || args.length != 7) {
            displayHelpAndExit();
        }
        String dataType = args[0];
        File input = new File(args[1]);
        File output = new File(args[2]);
        Integer pollingPeriod = Integer.valueOf(args[3]);

        try {
            URL monitoringServer = new URL(args[4]);

            // Check the arguments
            if (!input.canRead()) {
                displayMessageAndExit("Cannot read input directory " + input);
            }
            if (!output.canWrite()) {
                displayMessageAndExit(
                        "Cannot write output directory " + output);
            }

            if (args.length == 5) {
                // Run the polling task
                new LocalArchiveImporterTask(dataType, input, output,
                        pollingPeriod, monitoringServer);
            } else {
                // Credentials
                String user = args[5];
                String password = args[6];
                // Run the polling task
                new LocalArchiveImporterTask(dataType, input, output,
                        pollingPeriod, monitoringServer, user, password);
            }

        } catch (MalformedURLException e) {
            displayMessageAndExit("Invalid URL " + args[4]);
        }
    }

    /** Input directory. */
    private File inputDirectory;

    /** Output directory. */
    private File outputDirectory;

    /** Monitoring agent. */
    private MonitoringAgent monitoringAgent;

    /**
     * Constructor of the importer.
     * @param output
     *            Output directory
     * @param input
     *            Input directory
     * @param dataType
     *            Name of the data type
     * @param pollingPeriod
     *            Polling period (in seconds)
     * @param monitoringUrl
     *            Monitoring server URL
     * @param user
     *            Login de l'utilisateur pour la connexion à ElasticSearch
     * @param password
     *            Mot de passe de l'utilisateur pour la connexion à
     *            ElasticSearch
     */
    public LocalArchiveImporterTask(String dataType, File input, File output,
            int pollingPeriod, URL monitoringUrl, String user,
            String password) {
        // Store the directories
        inputDirectory = input;
        outputDirectory = output;
        // Initiate a connection to the monitoring server
        monitoringAgent = new ElasticMonitoringAgent(dataType, monitoringUrl,
                user, password);
        // Timer
        Timer timer = new Timer(false);
        timer.scheduleAtFixedRate(this, 0L, pollingPeriod * 1000);
    }

    /**
     * Constructor of the importer.
     * @param output
     *            Output directory
     * @param input
     *            Input directory
     * @param dataType
     *            Name of the data type
     * @param pollingPeriod
     *            Polling period (in seconds)
     * @param monitoringUrl
     *            Monitoring server URL
     */
    public LocalArchiveImporterTask(String dataType, File input, File output,
            Integer pollingPeriod, URL monitoringServer) {
        // Store the directories
        inputDirectory = input;
        outputDirectory = output;
        // Initiate a connection to the monitoring server
        monitoringAgent =
                new ElasticMonitoringAgent(dataType, monitoringServer);
        // Timer
        Timer timer = new Timer(false);
        timer.scheduleAtFixedRate(this, 0L, pollingPeriod * 1000);
    }

    /**
     * Detect the new files by comparing the content of the input and output
     * directories.
     * @return Collection of new files
     * @throws MonitoringException
     *             Impossible d'enregistrer les événements de supervision
     */
    private Collection<File> detectNewFiles() throws MonitoringException {
        Collection<File> newFiles = new ArrayList<File>();

        // Input and output content
        File[] inputs = inputDirectory.listFiles();
        File[] outputs = outputDirectory.listFiles();

        // Check for each input if it is already present in the output
        for (File input : inputs) {
            boolean isNew = true;
            for (File output : outputs) {
                isNew = isNew && (!input.getName().equals(output.getName()));
            }
            if (isNew && !input.getName().startsWith(".")) {
                newFiles.add(input);
                monitoringAgent.queueFile(input);
            }
        }

        return newFiles;
    }

    /**
     * Detect the files in the output directory and transfer them to the output
     * directory.
     */
    @Override
    public void run() {
        try {
            for (File file : detectNewFiles()) {
                transfer(file);
            }
        } catch (MonitoringException e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    /**
     * Transfer one file.
     * @param file
     *            File to transfer
     * @throws MonitoringException
     *             Cannot monitor the file transfer
     */
    private void transfer(File file) throws MonitoringException {
        try {
            // Monitor the transfer start
            monitoringAgent.startFile(file);
            // Copy a file
            Path inputPath = Paths.get(file.getAbsolutePath());
            File output = new File(outputDirectory, file.getName());
            Files.copy(inputPath, new FileOutputStream(output));
            Files.delete(inputPath);
            // Monitor the transfer end
            monitoringAgent.completeFile(file);
        } catch (IOException e) {
            // Monitor the transfer fail
            monitoringAgent.failFile(file);
        }
    }

}
