/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive.monitoring;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;

import fr.cnes.microcarb.validation.localarchive.time.TimeService;

/**
 * Implémentation ElasticSearch de l'agent de supervision.
 * @author Capgemini
 * @since 0.1.2
 */
public class ElasticMonitoringAgent implements MonitoringAgent {

    /** Format de la date des enregistrements. */
    private static final DateFormat DATE_FMT =
            new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");

    /** Format des enregistrements. */
    private static final String RECORD_FMT = "'{'\"file\":\"{0}\"," +
            "\"@timestamp\":\"{1}\"," +
            "\"type\":\"{2}\"," +
            "\"status\":\"{3}\"'}'";

    /** URL d'accès à la base Elastic. */
    private URL urlBase;

    /** Type de données de supervision. */
    private String type;

    /** Informations d'authentification. */
    private String authHeaderValue;

    /**
     * Constructeur de l'agent.
     * @param dataType
     *            Type de données de supervision
     * @param monitoringUrl
     *            URL de connexion au serveur Elastic Search
     */
    public ElasticMonitoringAgent(String dataType, URL monitoringUrl) {
        type = dataType;
        urlBase = monitoringUrl;
    }

    /**
     * Constructeur de l'agent.
     * @param dataType
     *            Type de données de supervision
     * @param monitoringUrl
     *            URL de connexion au serveur Elastic Search
     * @param user
     *            Login de l'utilisateur pour l'accès à Elastic
     * @param password
     *            Mot de passe de l'utilisateur pour l'accès à Elastic
     */
    public ElasticMonitoringAgent(String dataType, URL monitoringUrl,
            String user, String password) {
        type = dataType;
        urlBase = monitoringUrl;
        String auth = user + ":" + password;
        byte[] encodedAuth = Base64.getEncoder()
                .encode(auth.getBytes(StandardCharsets.UTF_8));
        authHeaderValue = "Basic " + new String(encodedAuth);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void completeFile(File file) throws MonitoringException {
        record("COMPLETED", file);
    }

    /**
     * Crée une connexion avec ElasticSearch.
     * @param url
     *            URL de la connexion à ouvrir
     * @return Connexion créée
     * @throws IOException
     *             Impossible d'ouvrir la connexion
     */
    private HttpURLConnection createConnection(URL url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        if (authHeaderValue != null) {
            con.setRequestProperty("Authorization", authHeaderValue);
        }
        return con;
    }

    /**
     * Crée l'index.
     */
    private void createIndex() throws IOException {

        // Connexion
        HttpURLConnection con = createConnection(urlBase);
        con.setRequestMethod("PUT");

        // Lecture du code HTTP
        int httpCode = con.getResponseCode();
        con.disconnect();
        if (httpCode != 200) {
            throw new IOException(
                    "Failed to create the index (status=" + httpCode + ")");
        }
    }

    /**
     * Vérifie si l'index existe déjà dans la base.
     * @return true Si l'index existe
     */
    private boolean doesIndexExist() {
        try {

            // Connexion
            HttpURLConnection con = createConnection(urlBase);
            con.setRequestMethod("GET");

            // Lecture du code HTTP
            int httpCode = con.getResponseCode();
            con.disconnect();
            return httpCode == 200;

        } catch (IOException e) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void failFile(File file) throws MonitoringException {
        record("FAILED", file);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void queueFile(File file) throws MonitoringException {
        record("QUEUED", file);
    }

    /**
     * Enregistre un contenu dans la base Elastic.
     * @param eventType
     *            Type de l'événement enregistré
     * @param file
     *            Fichier concerné par l'événement
     */
    private void record(String eventType, File file)
        throws MonitoringException {
        try {
            // Crée l'index si nécessaire
            if (!doesIndexExist()) {
                createIndex();
            }
            // Prépare le contenu de l'enregstrement JSON
            String now =
                    DATE_FMT.format(TimeService.getInstance().getCurrentDate());
            String record =
                    MessageFormat.format(RECORD_FMT, file.getName(), now, type,
                            eventType);
            writeData(file.getName(), record);
        } catch (IOException e) {
            throw new MonitoringException(e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void startFile(File file) throws MonitoringException {
        record("RUNNING", file);
    }

    /**
     * Ecrit un contenu dans la base Elastic.
     * @param id
     *            Identifiant du document
     * @param record
     *            Contenu à écrire
     * @throws IOException
     *             Impossible d'écrire la donnée
     */
    private void writeData(String id, String record) throws IOException {
        // Connexion
        URL url = new URL(urlBase + "/_doc/" + id);
        HttpURLConnection con = createConnection(url);
        con.setRequestMethod("POST");

        // Mise en forme des données à enregistrer
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json");
        OutputStreamWriter out =
                new OutputStreamWriter(con.getOutputStream());
        out.write(record);
        out.flush();
        out.close();

        // Read the response code
        int httpCode = con.getResponseCode();
        con.disconnect();
        if (httpCode / 200 != 1) {
            throw new IOException(
                    "Failed to write the data (status=" + httpCode + ")");
        }
    }
}
