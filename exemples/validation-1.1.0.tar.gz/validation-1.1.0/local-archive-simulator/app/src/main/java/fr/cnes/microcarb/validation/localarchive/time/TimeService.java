/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive.time;

import java.util.Date;
import java.util.NoSuchElementException;
import java.util.ServiceLoader;

/**
 * Cette interface propose les méthodes dont le comportement dépend de la date
 * courante.
 * @author Capgemini
 * @since 0.1.2
 */
public interface TimeService {

    /**
     * Récupère la date courante.
     * @return Date courante sous la forme d'une date Java
     */
    Date getCurrentDate();

    /**
     * Récupère une instance du TimeService en s'appuyant sur le mécanisme de
     * Service Loader de Java.
     * @return Instance du TimeService
     * @throws NoSuchElementException
     *             Exception levée si aucune implémentation du TimeService n'est
     *             disponible
     */
    static TimeService getInstance() throws NoSuchElementException {
        ServiceLoader<TimeService> load = ServiceLoader.load(TimeService.class);
        return load.findFirst().get();
    }
}
