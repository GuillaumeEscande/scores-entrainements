/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive.monitoring;

/**
 * Exception levée lorsqu'une donnée de supervision ne peut pas être prise en
 * charge par l'agent.
 * @author Capgemini
 * @since 0.1.2
 */
public class MonitoringException extends Exception {

    /** Serial version UID. */
    private static final long serialVersionUID = 1009402154960037510L;

    /**
     * Constructeur de l'exception.
     * @param cause
     *            Cause de l'exception levée par la façade
     */
    public MonitoringException(final Throwable cause) {
        super(cause);
    }
}
