/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

/**
 * Local archive importer set daemon.
 * @author Capgemini
 * @since 0.1.2
 */
public class LocalArchiveImporter {

    /** Monitoring URL parameter key. */
    private static final String MONITORING_URL = "MONITORING_URL";

    /** Polling period parameter key. */
    private static final String POLLING_PERIOD = "POLLING_PERIOD";

    /** Base input parameter key. */
    private static final String BASE_INPUT = "BASE_INPUT";

    /** Base output parameter key. */
    private static final String BASE_OUTPUT = "BASE_OUTPUT";

    /** User login key. */
    private static final String USER_LOGIN = "USER_LOGIN";

    /** User password key. */
    private static final String USER_PASSWORD = "USER_PASSWORD";

    /** Data type parameter key prefix. */
    private static final String DATA_TYPE = "DATA_TYPE_";

    /**
     * Constructor of the importer.
     * @param descriptor
     *            Descriptor file for the import to manage
     * @throws IOException
     *             Cannot read the descriptor
     */
    public LocalArchiveImporter(File descriptor) throws IOException {
        // Read the descriptor as a property file
        Properties properties = new Properties();
        properties.load(new FileInputStream(descriptor));

        // Get the mandatory standalone arguments
        URL monitoringUrl = new URL(properties.getProperty(MONITORING_URL));
        int pollingPeriod =
                Integer.parseInt(properties.getProperty(POLLING_PERIOD));
        File baseInput = new File(properties.getProperty(BASE_INPUT));
        File baseOutput = new File(properties.getProperty(BASE_OUTPUT));
        String userLogin = properties.getProperty(USER_LOGIN);
        String userPassword = properties.getProperty(USER_PASSWORD);

        // Get the data type arguments
        for (Object okey : properties.keySet()) {
            String key = okey.toString();
            if (key.startsWith(DATA_TYPE)) {

                // Extract the metadata of the current data type
                String fullType = key.substring(DATA_TYPE.length());
                String dataType = properties.getProperty(key);
                File input = new File(baseInput, fullType);
                File output = new File(baseOutput, dataType);

                // Check the directories
                if (!input.canRead()) {
                    System.err.println("Cannot read directory " + input);
                } else if (!output.canWrite()) {
                    System.err.println("Cannot write directory " + output);
                } else if (userLogin == null || userPassword == null) {
                    // Create the importer task for this data type
                    new LocalArchiveImporterTask(dataType, input, output,
                            pollingPeriod, monitoringUrl);
                } else {
                    // Create the importer task for this data type
                    new LocalArchiveImporterTask(dataType, input, output,
                            pollingPeriod, monitoringUrl, userLogin,
                            userPassword);
                }
            }
        }
    }

    /**
     * Main function.
     * @param args
     *            The daemon accepts only one argument that consists of a file
     *            describing the importer tasks to run.
     *            <ol>
     *            <li>Name of the data type</li>
     *            <li>Input directory</li>
     *            <li>Output directory</li>
     *            <li>Polling period in seconds</li>
     *            <li>PLGS-LOG address</li>
     *            </ol>
     */
    public static void main(String[] args) {
        // Read the arguments
        if (args.length != 1) {
            System.err.println("The program accepts only one argument");
            System.exit(-1);
        }
        File descriptor = new File(args[0]);

        try {
            // Importer
            new LocalArchiveImporter(descriptor);
            // Say that the importer is loaded
            System.out.println("Local archive importer is running");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
