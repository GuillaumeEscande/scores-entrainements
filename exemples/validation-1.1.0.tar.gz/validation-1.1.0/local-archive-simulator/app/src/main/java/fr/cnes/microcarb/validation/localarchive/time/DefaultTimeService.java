/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive.time;

import java.util.Date;

/**
 * Implémentation par défaut du TimeService.
 * @author capgemini
 * @since 0.1.2
 */
public class DefaultTimeService implements TimeService {

    /**
     * {@inheritDoc}
     */
    @Override
    public Date getCurrentDate() {
        return new Date();
    }
}
