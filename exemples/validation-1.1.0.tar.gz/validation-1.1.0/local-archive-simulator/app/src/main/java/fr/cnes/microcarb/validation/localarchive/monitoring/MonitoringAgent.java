/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:0.2.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */
package fr.cnes.microcarb.validation.localarchive.monitoring;

import java.io.File;

/**
 * Agent de supervision applicative.
 * @author Capgemini
 * @since 0.1.2
 */
public interface MonitoringAgent {

    /**
     * Enregistre l'événement de fin nominale de transfer d'un fichier.
     * @param file
     *            Fichier transféré
     * @throws MonitoringException
     *             Impossible d'enregistrer l'événement
     */
    public void completeFile(File file) throws MonitoringException;

    /**
     * Enregistre l'événement d'échec de transfert d'un fichier.
     * @param file
     *            Fichier à transférer
     * @throws MonitoringException
     *             Impossible d'enregistrer l'événement
     */
    public void failFile(File file) throws MonitoringException;

    /**
     * Enregistre l'événement de mise en queue d'un fichier.
     * @param file
     *            Fichier mis en attente
     * @throws MonitoringException
     *             Impossible d'enregistrer l'événement
     */
    public void queueFile(File file) throws MonitoringException;

    /**
     * Enregistre l'événement de début de transfer d'un fichier.
     * @param file
     *            Fichier à transférer
     * @throws MonitoringException
     *             Impossible d'enregistrer l'événement
     */
    public void startFile(File file) throws MonitoringException;
}
