#!/usr/bin/env python3.7.4
# -*- coding: utf-8 -*-

"""
# * ======================================================
# * Projet : PLGS
# * Produit par Capgemini
# * ======================================================
# * HISTORIQUE
# * VERSION:1.0.0::::Creation  
# * FIN-HISTORIQUE
# * ======================================================
"""

import pathlib
from setuptools import setup, find_packages


HERE = pathlib.Path(__file__).parent
INSTALL_REQUIRES = (HERE / "requirements.txt").read_text().splitlines()
TESTS_REQUIRE = (HERE / "test-requirements.txt").read_text().splitlines()[1:]

NAME = "testreportprocessor"
VERSION = "1.1.0"

setup(
    name=NAME,
    version=VERSION,
    description="testreportprocessor",
    author_email="",
    url="",
    keywords=["testreportprocessor"],
    install_requires=INSTALL_REQUIRES,
    tests_require=TESTS_REQUIRE,
    packages=find_packages(),
    entry_points={
        'console_scripts': ['testreportprocessor=testreportprocessor.__main__:main']},
)

