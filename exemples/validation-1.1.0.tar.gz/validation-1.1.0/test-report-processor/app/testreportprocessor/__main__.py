# ======================================================
# Projet : PLGS
# Produit par Capgemini
# ======================================================
# HISTORIQUE
# VERSION:1.0.0::::Creation
# VERSION:1.1.0:Story:MCA_PLGS_T-226:11/03/2021:Analyse préliminaire de l'automatisation de l'analyse qualité d'un composant/bundle
# VERSION:1.1.0:Story:MCA_PLGS_T-329:11/03/2021:Activer TU dans le build sans bloquer le build
# FIN-HISTORIQUE
# ======================================================


import argparse
import json
import os
import requests
import sys

def garbage():
        # Query the campaign
    response = requests.get(args.api+"/"+args.campaign,
                            auth=(args.user, args.password),verify=False)
    issue = json.loads(response.text)
    print(issue["id"])

    # Test a rendering of JSON
    test_data = {
        "id": 123,
        "label": "My test"
    }
    query_data = json.dumps(test_data)
    print(query_data)


def parseReport(file):
    report = {}

    with open(file) as raw_report:
        # Parse the JSON Payload
        report_data = json.load(raw_report)
        report = []
        
        # Iterate on the test records
        for record in report_data:        
            # New test record
            test_record = {
                "name": record["name"],
                "case": os.path.splitext(os.path.basename(record["uri"]))[0],
                "description": record["description"]
            }
            report.append(test_record)
            
            # Iteration variables
            test_execution_report = ""
            test_has_failure = False
            test_has_success = False
            
            # Analyze the steps of the test record
            for element in record["elements"]:
                test_execution_report = test_execution_report + "===> " + element["name"] + '\n'
                for step in element["steps"]:
                    status = step["result"]["status"]
                    if status == "passed":
                        test_has_success = True
                    elif status == "failed":
                        test_has_failure = True
                    test_execution_report = test_execution_report + step["name"] + " [" + status + "]\n"

            # Make a synthesis of the steps
            test_record["test_execution_report"] = test_execution_report
            if test_has_failure and test_has_success:
                test_record["status_transition"] = 71 # POK
            elif test_has_failure:
                test_record["status_transition"] = 51 # KO
            elif test_has_success:
                test_record["status_transition"] = 61 # OK
    
    return report


def createTestRecord(record, args):
    
    # Record data
    recordData = {
        "fields": {
            "project": {
                "key": "MCA_TEST"
            },
            "summary": record["name"],
            "description": record["description"],
            "issuetype": {
                "name": "Test Record"
            },
            "customfield_10618": record["test_execution_report"]
        },
        "update": {
            "issuelinks": [{
                "add": {
                    "type": {
                        "name": "Cloners"
                    },
                    "outwardIssue": {
                        "key": record["case"]
                    }
                }
            }]
        }
    }
    
    # Post the record
    print("NEW    => {}".format(record["name"]))
    response = requests.post(args.api,
                             auth=(args.user, args.password),
                             headers={'Content-Type': 'application/json'},
                             json=recordData,verify=False)
    issue = json.loads(response.text)
    recordKey = issue["key"]
    print("CREATE => {} [{}]".format(recordKey, response.status_code))
    return recordKey


def attachTestRecordToCampaign(recordKey, args):
    
    # Update data
    updateData = {
        "update": {
            "issuelinks": [{
                "add": {
                    "type": {
                        "name": "Contains"
                    },
                    "inwardIssue": {
                        "key": args.campaign
                    }
                }
            }]
        }
    }
    
    # Post the record
    response = requests.put(args.api+"/"+recordKey,
                            auth=(args.user, args.password),
                            headers={'Content-Type': 'application/json'},
                            json=updateData,verify=False)
    print("ATTACH => {} [{}]".format(recordKey, response.status_code))


def triggerTransition(recordKey, record, args):
    
    # Update data
    updateData = {
        "transition": {
            "id": record["status_transition"]
        }
    }
    
    # Post the record
    response = requests.post(args.api+"/"+recordKey+"/transitions",
                             auth=(args.user, args.password),
                             headers={'Content-Type': 'application/json'},
                             json=updateData,verify=False)
    print("STATUS => {} [{}]".format(recordKey, response.status_code))


def importRecord(record, args):
    
    # First create the test record
    recordKey = createTestRecord(record, args)
    
    # Then update the link to the test campaign
    attachTestRecordToCampaign(recordKey, args)
    
    # Finally trigger the transition
    triggerTransition(recordKey, record, args)
    
    
if __name__ == '__main__':

    # Define expected arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", "--api", help="Base URL of the JIRA API to use")
    parser.add_argument("-c", "--campaign", type=str, help="Key of the JIRA campaign to populate")
    parser.add_argument("-i", "--input", type=str, help="Report to process")
    parser.add_argument("-p", "--password", type=str, help="User password")
    parser.add_argument("-r", "--report", type=str, help="Path to the report to load")
    parser.add_argument("-u", "--user", type=str, help="User login")
    args = parser.parse_args()

    # Check the arguments
    if args.api is None:
        print("Missing API URL")
        sys.exit()
    if args.campaign is None:
        print("Missing campaign key")
        sys.exit()
    if args.user is None:
        print("Missing user login")
        sys.exit()
    if args.password is None:
        print("Missing user password")
        sys.exit()
    if args.input is None:
        print("Missing report to process")
        sys.exit()
    
    # Parse the input report
    report = parseReport(args.input)
    
    # Import each record of the report
    for record in report:
        importRecord(record, args)
