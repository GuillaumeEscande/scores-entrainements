# ======================================================
# Projet : PLGS
# Produit par Capgemini
# ======================================================
# HISTORIQUE
# VERSION:1.1.0::::Creation
# VERSION:1.1.0:Story:MCA_PLGS_T-226:11/03/2021:Analyse préliminaire de l'automatisation de l'analyse qualité d'un composant/bundle
# VERSION:1.1.0:Story:MCA_PLGS_T-329:11/03/2021:Activer TU dans le build sans bloquer le build
# FIN-HISTORIQUE
# ======================================================

"""
Module définition
"""
