# Test Report Processor

## Overview
This validation tool is in charge of processing a Cucumber test execution
report in JSON format, and to drive the REST API of a JIRA instance to create
the test record included in the report.

## Requirements
Python 3.7.4

## Usage
The tool must be used from a machine of the CNES network. Indeed the JIRA API
used by the tool is not accessible from external machines. It is important 
however to note that the CNES environment may not natively support the Python
libraries used by this tool. It might therefore be necessary to install a
virtual environment. The following instruction should then be considered:
https://gitlab.cnes.fr/hpc/wikiHPC/-/wikis/utilisation-virtual-env-python#mise-en-place-du-virtualenv.
To run the tool, please execute the following from the root directory:

```
python testreportprocessor -a <api> -u <login> -p <password> -c <CAMPAIGN> -i <REPORT>

-h, --help
     show the help message and exit

-a, --api URL
    URL of the JIRA issue API to use to populate the issue database
    (for instance https://jira.cnes.fr/rest/api/latest/issue)

-u, --user LOGIN
    Login of the user to log into the API

-p, --password PASSWORD
    API token associated to the user used to log into the API

-c, --campaign CAMPAIGN
    Key of the JIRA issue denoting the campaign to which the created
    record must be associated to (for instance MCA_TEST-21)

-i, --input REPORT
    Path to the Cucumber report in JSON format to parse in order
    to create the test records (for instance report.json)
```
