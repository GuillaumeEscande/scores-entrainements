/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

/**
 * Process a packet.
 */
public interface PacketProcessor {

    /**
     * Process a packet.
     * @param packets
     *            Collection of byte including the packet to process
     * @param offset
     *            Offset of the packet start in the packets buffer
     * @param length
     *            Length of the packet in bytes
     */
    void process(byte[] packets, int offset, int length);
}
