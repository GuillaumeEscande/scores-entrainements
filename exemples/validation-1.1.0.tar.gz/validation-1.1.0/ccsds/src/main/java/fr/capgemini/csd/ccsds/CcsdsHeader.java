/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

/**
 * CCSDS main header.
 */
public class CcsdsHeader {

    /** Application process identifier. */
    private short apid;

    /** Packet length. */
    private int packetLength;

    /** Secondary header flag. */
    private boolean secondaryHeaderFlag;

    /**
     * Constructor.
     * @param secondaryHeader
     *            Presence of the secondary header
     * @param headerApid
     *            Application process identifier
     * @param packetLength
     *            Length of the packet
     */
    public CcsdsHeader(boolean secondaryHeader, short headerApid, int headerPacketLength) {
        secondaryHeaderFlag = secondaryHeader;
        apid = headerApid;
        packetLength = headerPacketLength;
    }

    /**
     * Get the packet APID.
     * @return Application process identifier
     */
    public short getApid() {
        return apid;
    }

    /**
     * Get the packet length.
     * @return Length of the packet in bytes
     */
    public int getPacketLength() {
        return packetLength;
    }

    /**
     * Get the secondary header flag.
     * @return Presence of a secondary header
     */
    public boolean getSecondaryHeaderFlag() {
        return secondaryHeaderFlag;
    }
}
