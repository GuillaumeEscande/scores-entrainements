/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.TreeMap;

/**
 * Merger (and sorter) of CCSDS packets.
 */
public class PacketMerger implements PacketProcessor {

    /**
     * Main entry point of the command line.
     */
    public static void main(String[] args) {
        // Check arguments
        if (args.length < 2) {
            System.err.println(
                    "At least two arguments expected: the output file and one input file");
        }
        // Create a packet merger instance
        PacketMerger merger = new PacketMerger();
        // And a packet decom
        DecomPacket decom = new DecomPacket();
        // Read the packets in input files and add them to the packet merger
        for (int inputIndex = 1; inputIndex < args.length; inputIndex++) {
            String input = args[inputIndex];
            File inputFile = new File(input);
            try {
                decom.process(inputFile, merger);
            } catch (IOException e) {
                // Error processing
                System.err.println("Cannot process input " + input);
                e.printStackTrace();
            }
        }
        // Write the merged packets
        try {
            FileOutputStream output = new FileOutputStream(args[0]);
            output.write(merger.merge());
            output.close();
        } catch (IOException e) {
            System.err.println("Cannot write to output " + args[0]);
            e.printStackTrace();
        }
    }

    /** Packets to merge. */
    private Map<MyriadesHeader, byte[]> packets;

    /**
     * Constructor.
     */
    public PacketMerger() {
        packets = new TreeMap<MyriadesHeader, byte[]>();
    }

    /**
     * Add a packet to the merge.
     * @param packet
     *            Packet to add to the merger
     */
    public void addPacket(byte[] packet) {
        // Decommute the packet
        DecomPacket decom = new DecomPacket();
        MyriadesHeader header = decom.getMyriadesHeader(packet, 0);
        // And index with the header
        packets.put(header, packet);
    }

    /**
     * Compute the size of all the packets in bytes.
     * @return Size of the packets in bytes
     */
    private int computePacketsSize() {
        int size = 0;
        for (byte[] packet : packets.values()) {
            size += packet.length;
        }
        return size;
    }

    /**
     * Sort and merge the packets.
     * @return The sorted and merged packet
     */
    public byte[] merge() {
        int globalSize = computePacketsSize();
        ByteBuffer buffer = ByteBuffer.allocate(globalSize);
        for (byte[] packet : packets.values()) {
            buffer.put(packet);
        }
        return buffer.array();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void process(byte[] packets, int offset, int length) {
        // Extract the packet data
        byte[] packet = new byte[length];
        for (int index = 0; index < length; index++) {
            packet[index] = packets[index + offset];
        }
        // And add them to the merger
        addPacket(packet);
    }

}
