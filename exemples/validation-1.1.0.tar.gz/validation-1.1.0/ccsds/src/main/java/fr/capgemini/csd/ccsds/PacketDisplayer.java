/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

/**
 * Display a packet.
 */
public class PacketDisplayer implements PacketProcessor {

    /**
     * {@inheritDoc}
     */
    @Override
    public void process(byte[] packets, int offset, int length) {
        // Packet decom
        DecomPacket decom = new DecomPacket();
        
        // Read the CCSDS Header
        CcsdsHeader ccsds = decom.getCcsdsHeader(packets, offset);
        System.out.println("========== PACKET ==========");
        System.out.println("APID   = " + ccsds.getApid());
        System.out.println("Length = " + ccsds.getPacketLength());

        // Read the secondary Header
        int dataOffset = 6;
        if (ccsds.getSecondaryHeaderFlag()) {
            MyriadesHeader myriades = decom.getMyriadesHeader(packets, offset);
            System.out.println("Date   = " + myriades.getDate());
            dataOffset += 10;
        }

        // Read the data
        for (int index = dataOffset; index < length; index++) {
            System.out.printf("%02X ", packets[index]);
        }
        System.out.println("");
    }

}
