/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 * Decommute CCSDS telemetry packet.
 */
class DecomPacket {

    /** Position of the APID in the packet (at the byte level). */
    private static final int APID_OFFSET = 0;

    /** Mask of the APID in the packet. */
    private static final int APID_MASK = 0x7F;

    /** Position of the date in the packet. */
    private static final int DATE_OFFSET = 6;

    /** Mask of microseconds. */
    private static final int MICRO_MASK = 0x00FFFFF0;

    /** Shift of microseconds. */
    private static final int MICRO_SHIFT = 4;

    /** Position of the packet length in the packet. */
    private static final int PACKET_LENGTH_OFFSET = 4;

    /** Mask of the secondary header flag. */
    private static final int SEC_HEADER_FLAG_MASK = 0x80;

    /** Position of the secondary header flag in the CCSDS header. */
    private static final int SEC_HEADER_FLAG_OFFSET = 0;

    /**
     * Main entry point of the command line.
     */
    public static void main(String[] args) {
        // Processor initialization
        DecomPacket decom = new DecomPacket();
        // Get input
        if (args.length != 1) {
            System.err.println("Expect one argument: packet file to process");
            System.exit(-1);
        }
        File input = new File(args[0]);
        try {
            // Process
            decom.process(input, new PacketDisplayer());
        } catch (IOException e) {
            // Error processing
            e.printStackTrace();
        }
    }

    /**
     * Process the input file.
     * @param input
     *            Input packet file
     * @param processor
     *            Packet processor
     * @throws IOException
     *             Cannot read the input file
     */
    public void process(File input, PacketProcessor processor) throws IOException {
        // Map the input file in memory
        int inputSize = (int) input.length();
        byte[] buffer = new byte[inputSize];
        FileInputStream fis = new FileInputStream(input);
        fis.read(buffer);
        fis.close();

        // Main loop
        int offset = 0;
        int length = getPacketLength(buffer, 0) + 6;
        int packetEnd = length;
        boolean endOfFile = false;
        while (!endOfFile) {

            // Process the packet
            processor.process(buffer, offset, length);

            // Update the position indices
            if (packetEnd == inputSize) {
                endOfFile = true;
            } else {
                offset = packetEnd;
                length = getPacketLength(buffer, offset) + 6;
                packetEnd = packetEnd + length;
            }
        }
    }

    /**
     * Get the length of the packet at the given offset in the given buffer.
     * @param packets
     *            Buffer containing the packets to analyze
     * @param packetOffset
     *            Offset of the current packet
     * @return Length of the packet at the given offset
     */
    protected int getPacketLength(byte[] packets, int packetOffset) {
        ByteBuffer buffer = ByteBuffer.wrap(packets);
        return buffer.getShort(packetOffset + PACKET_LENGTH_OFFSET) + 1;
    }

    /**
     * Get the CCSDS header from the packet at the given position.
     * @param packets
     *            Byte array containing the header to extract
     * @param packetOffset
     *            Offset of the packet in the byte array
     * @return The CCSDS main header
     */
    protected CcsdsHeader getCcsdsHeader(byte[] packets, int packetOffset) {
        ByteBuffer buffer = ByteBuffer.wrap(packets);
        boolean secondaryFlag = ((buffer.get(packetOffset + SEC_HEADER_FLAG_OFFSET) |
                SEC_HEADER_FLAG_MASK) != 0);
        short apid = (short) (buffer.getShort(packetOffset + APID_OFFSET) & APID_MASK);
        int packetLength = buffer.getShort(packetOffset + PACKET_LENGTH_OFFSET);
        return new CcsdsHeader(secondaryFlag, apid, packetLength);
    }

    /**
     * Get the Myriades secondary header from the packet starting at the given
     * position.
     * @param packets
     *            Byte array containing the header to extract
     * @param packetOffset
     *            Offset of the packet in the byte array
     * @return The Myriades secondary header
     */
    protected MyriadesHeader getMyriadesHeader(byte[] packets, int packetOffset) {
        // Extract raw data
        ByteBuffer buffer = ByteBuffer.wrap(packets);
        short year = buffer.getShort(packetOffset + DATE_OFFSET);
        byte month = buffer.get(packetOffset + DATE_OFFSET + 2);
        byte day = buffer.get(packetOffset + DATE_OFFSET + 3);
        byte hour = buffer.get(packetOffset + DATE_OFFSET + 4);
        byte minute = buffer.get(packetOffset + DATE_OFFSET + 5);
        byte second = buffer.get(packetOffset + DATE_OFFSET + 6);
        int milli =
                (buffer.getInt(packetOffset + DATE_OFFSET + 6) & MICRO_MASK >> MICRO_SHIFT) / 1000;
        // Convert raw data
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, second);
        cal.set(Calendar.MILLISECOND, milli);
        return new MyriadesHeader(cal.getTime());
    }
}
