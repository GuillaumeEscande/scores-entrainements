/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

import java.util.Date;

/**
 * Myriades secondary header.
 */
public class MyriadesHeader implements Comparable<MyriadesHeader> {

    /** Date of the packet. */
    private Date date;

    /**
     * Constructor.
     * @param packetDate
     *            Date of the packet
     */
    public MyriadesHeader(Date packetDate) {
        date = packetDate;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int compareTo(MyriadesHeader other) {
        int result = date.compareTo(other.date);
        if (result == 0) {
            result = hashCode() - other.hashCode();
        }
        return result;
    }

    /**
     * Get the timestamp of the packet.
     * @return Packet date
     */
    public Date getDate() {
        return date;
    }
}
