/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Unit test for DecomPacket class.
 */
public class TestDecomPacket {

    /**
     * Write a CCSDS header at a given position.
     */
    protected void writeCcsdsHeader(byte[] buffer,
            int position,
            boolean secondaryHeader,
            int apid,
            int sourceSequenceCount,
            int packetLength) {
        // Compute the APID header
        int apidHeader = secondaryHeader ? 1 : 0;
        apidHeader = apidHeader << 11 | apid;
        // Compute the Source Sequence Count header
        int sscHeader = 3;
        sscHeader = sscHeader << 14 | sourceSequenceCount;
        // Write the header
        ByteBuffer header = ByteBuffer.wrap(buffer);
        header.putShort(position, (short) apidHeader);
        header.putShort(position + 2, (short) sscHeader);
        header.putShort(position + 4, (short) packetLength);
    }

    /**
     * Write a secondary header at a given position.
     */
    protected void writeSecondaryHeader(byte[] packet, int position, Date date) {
        // Initialize the calendar
        Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.setTime(date);
        // Write the header
        ByteBuffer header = ByteBuffer.wrap(packet);
        int secMicro = cal.get(GregorianCalendar.SECOND) << 24;
        secMicro = secMicro | cal.get(GregorianCalendar.MILLISECOND) * 1000;
        header.putShort(position, (short) cal.get(GregorianCalendar.YEAR));
        header.put(position + 2, (byte) (cal.get(GregorianCalendar.MONTH) + 1));
        header.put(position + 3, (byte) cal.get(GregorianCalendar.DAY_OF_MONTH));
        header.put(position + 4, (byte) cal.get(GregorianCalendar.HOUR_OF_DAY));
        header.put(position + 5, (byte) cal.get(GregorianCalendar.MINUTE));
        header.putInt(position + 6, secMicro);
        header.putInt(position + 10, 0);
    }

    @Test
    public void getPacketLength_GlobalSize_OnePacket() {
        // GIVEN a single packet
        DecomPacket decom = new DecomPacket();
        byte[] packet = new byte[6 + 14 + 11];
        writeCcsdsHeader(packet, 0, true, 70, 12345, 24);
        writeSecondaryHeader(packet, 6, new Date());
        // WHEN the packet length is retrieved
        int length = decom.getPacketLength(packet, 0);
        // THEN the length is 24+1
        assertEquals(24 + 1, length);
    }

    @Test
    public void getCcsdsHeader_SimpleHeader_OnePacket() {
        // GIVEN a single packet
        DecomPacket decom = new DecomPacket();
        byte[] packet = new byte[6 + 14 + 10];
        writeCcsdsHeader(packet, 0, true, 70, 12345, 24);
        writeSecondaryHeader(packet, 6, new Date());
        // WHEN the main header is retrieved
        CcsdsHeader header = decom.getCcsdsHeader(packet, 0);
        // THEN the info extracted from the packet are correct
        assertEquals(true, header.getSecondaryHeaderFlag());
        assertEquals(70, header.getApid());
        assertEquals(24, header.getPacketLength());
    }

    @Test
    public void getMyriadesHeader_SimpleHeader_OnePacket() {
        // GIVEN a single packet
        DecomPacket decom = new DecomPacket();
        Date now = new Date();
        byte[] packet = new byte[6 + 14 + 10];
        writeCcsdsHeader(packet, 0, true, 70, 12345, 24);
        writeSecondaryHeader(packet, 6, now);
        // WHEN the main header is retrieved
        MyriadesHeader header = decom.getMyriadesHeader(packet, 0);
        // THEN the info extracted from the packet are correct
        assertEquals(now, header.getDate());
    }

}
