/**
 * ======================================================
 * Projet : PLGS
 * Produit par Capgemini
 * ======================================================
 * HISTORIQUE
 * VERSION:1.1.0::::Creation
 * FIN-HISTORIQUE
 * ======================================================
 */

package fr.capgemini.csd.ccsds;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Unit test for DecomPacket class.
 */
public class TestDecomPacketMerger extends TestDecomPacket {

    @Test
    public void merge_SortedPacketSet_UnsortedPackets() {
        int packetSize = 6 + 14 + 10;
        // GIVEN a first packet
        Date date1 = new Date();
        byte[] packet1 = new byte[packetSize];
        writeCcsdsHeader(packet1, 0, true, 70, 12345, 24);
        writeSecondaryHeader(packet1, 6, date1);
        // AND a second packet
        Date date2 = new Date(date1.getTime() + 1000);
        byte[] packet2 = new byte[packetSize];
        writeCcsdsHeader(packet2, 0, true, 71, 12345, 24);
        writeSecondaryHeader(packet2, 6, date2);
        // AND a third packet
        Date date3 = new Date(date2.getTime() + 1000);
        byte[] packet3 = new byte[packetSize];
        writeCcsdsHeader(packet3, 0, true, 72, 12345, 24);
        writeSecondaryHeader(packet3, 6, date3);
        // AND a merger of packets
        PacketMerger merger = new PacketMerger();
        // WHEN the packets are merged
        merger.addPacket(packet2);
        merger.addPacket(packet3);
        merger.addPacket(packet1);
        byte[] merged = merger.merge();
        // THEN they are sorted in chronological order
        DecomPacket packet = new DecomPacket();
        assertEquals(3 * packetSize, merged.length);
        assertEquals(70, packet.getCcsdsHeader(merged, 0).getApid());
        assertEquals(71, packet.getCcsdsHeader(merged, packetSize).getApid());
        assertEquals(72, packet.getCcsdsHeader(merged, 2 * packetSize).getApid());
    }

}
